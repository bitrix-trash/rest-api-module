<?
$MESS['UNSTEP_MODULE'] = 'Модуль';
$MESS['UNSTEP_REMOVED'] = 'удалён';
$MESS['UNSTEP_BACK'] = 'Вернуться';
