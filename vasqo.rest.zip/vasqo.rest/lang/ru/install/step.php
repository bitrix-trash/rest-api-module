<?
$MESS['STEP_RETURN'] = 'Вернуться';
$MESS['STEP_MODULE'] = 'Модуль';
$MESS['STEP_INSTALLED'] = 'установлен';
