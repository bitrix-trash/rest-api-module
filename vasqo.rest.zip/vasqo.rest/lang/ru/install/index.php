<?$MESS['INSTALL_DESC'] = 'REST API Module';
$MESS["INSATLL_NAME"]= "Vasqo REST API";
$MESS['INSATLL_INSATLL'] = 'Установка модуля';
$MESS['INSATALL_ERROR'] = 'Ошибка установки. Обновите битрикс.';
$MESS['INSTALL_UNINSTALL'] = 'Удаление модуля';
