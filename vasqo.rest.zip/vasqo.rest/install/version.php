<?php
$arModuleVersion = [
    "VERSION"        => "1.0.0",
    "VERSION_DATE" => "2022-03-29 14:23:00",
];