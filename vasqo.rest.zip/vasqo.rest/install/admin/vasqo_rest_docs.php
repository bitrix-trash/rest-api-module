<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/vasqo.rest/admin/layouts/vasqo_rest_docs.php");

