<?php
namespace Vasqo\Rest;

class Module
{
    public const MODULE_ID = 'vasqo.rest';
}