<?php


namespace Vasqo\Rest\Api\Middlewares;


use Vasqo\Rest\Api\Core\Middleware\AbstractMiddleware;

class TestMiddleware extends AbstractMiddleware
{

    public function execute(): void
    {
        // TODO: Implement execute() method.
    }
}