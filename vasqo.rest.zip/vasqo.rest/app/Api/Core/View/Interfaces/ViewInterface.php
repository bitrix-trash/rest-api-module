<?php


namespace Vasqo\Rest\Api\Core\View\Interfaces;


interface ViewInterface
{

}