<?php
define("ADMIN_MODULE_NAME", \Vasqo\Rest\Module::MODULE_ID);